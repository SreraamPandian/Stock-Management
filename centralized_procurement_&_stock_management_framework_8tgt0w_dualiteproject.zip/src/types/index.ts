export type Role = 
  | 'Sub Store Keeper' 
  | 'Centre In-Charge' 
  | 'Central Store' 
  | 'Procurement Officer' 
  | 'SMD' 
  | 'Finance';

export type Priority = 'Normal' | 'Medium' | 'High' | 'Emergency';

export type PRStatus = 
  | 'Pending - Centre In-Charge' 
  | 'Pending - Central Store' 
  | 'Pending - Procurement' 
  | 'Pending - SMD' 
  | 'Pending - Finance' 
  | 'PO Issued' 
  | 'Dispatched - In Transit'
  | 'Closed - Completed' 
  | 'Rejected - Action Required';

export type Tab = 'Dashboard' | 'PR Entry' | 'Stock' | 'Analytics' | 'Admin';

export interface PRHistory {
  id: string;
  stage: string;
  action: string;
  timestamp: number;
  userRole: Role;
  notes?: string;
}

export interface PurchaseRequest {
  id: string;
  branch: string;
  department: string;
  category: string;
  quantity: number;
  requester: string;
  priority: Priority;
  status: PRStatus;
  createdAt: number;
  slaDeadline: number;
  smdApproved: boolean;
  history: PRHistory[];
  vendor?: string;
  price?: number;
  paymentMode?: string;
}
