import React, { useState } from 'react';
import { useProcurement } from '../../context/ProcurementContext';
import { Priority } from '../../types';
import { BarcodeScanner } from './BarcodeScanner';

export const NewPRForm = ({ onClose }: { onClose: () => void }) => {
  const { addPR, branch } = useProcurement();
  const [isManual, setIsManual] = useState(false);
  
  const [formData, setFormData] = useState({
    department: 'General Ward',
    category: 'Consumables',
    quantity: 1,
    priority: 'Normal' as Priority,
    requester: 'Current User'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    let slaHours = 24;
    if (formData.priority === 'Emergency') slaHours = 2;
    if (formData.priority === 'High') slaHours = 8;
    if (formData.priority === 'Medium') slaHours = 12;

    addPR({
      ...formData,
      branch, // Automatically assign to current branch
      status: 'Pending - Centre In-Charge',
      slaDeadline: Date.now() + (slaHours * 3600000)
    });
    if(onClose) onClose();
  };

  return (
    <div className="w-full">
      <div className="p-6 border-b border-slate-100 bg-blue-600 text-white rounded-t-xl">
        <h2 className="text-xl font-bold">Raise New Purchase Request</h2>
        <p className="text-blue-100 text-sm mt-1">Sub Store Initiation - {branch}</p>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-5 bg-white rounded-b-xl">
        <div className="flex items-center justify-between bg-slate-50 p-3 rounded-lg border border-slate-200">
          <span className="text-sm font-medium text-slate-700">Entry Method</span>
          <label className="flex items-center cursor-pointer">
            <div className="relative">
              <input type="checkbox" className="sr-only" checked={isManual} onChange={() => setIsManual(!isManual)} />
              <div className={`block w-10 h-6 rounded-full transition-colors ${isManual ? 'bg-blue-500' : 'bg-slate-300'}`}></div>
              <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${isManual ? 'transform translate-x-4' : ''}`}></div>
            </div>
            <span className="ml-3 text-sm font-medium text-slate-700">{isManual ? 'Manual Entry' : 'Barcode Scan'}</span>
          </label>
        </div>

        {!isManual && (
          <BarcodeScanner onScan={(code) => console.log('Scanned for PR:', code)} />
        )}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Department</label>
            <select 
              className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              value={formData.department}
              onChange={e => setFormData({...formData, department: e.target.value})}
            >
              <option>General Ward</option>
              <option>ICU</option>
              <option>Pharmacy</option>
              <option>Laboratory</option>
              <option>Dental</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Category</label>
            <select 
              className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              value={formData.category}
              onChange={e => setFormData({...formData, category: e.target.value})}
            >
              <option>Consumables</option>
              <option>Surgical Instruments</option>
              <option>Medications</option>
              <option>Equipment</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Quantity</label>
            <input 
              type="number" 
              min="1"
              className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              value={formData.quantity}
              onChange={e => setFormData({...formData, quantity: parseInt(e.target.value)})}
              required
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Priority</label>
            <select 
              className="w-full border border-slate-300 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              value={formData.priority}
              onChange={e => setFormData({...formData, priority: e.target.value as Priority})}
            >
              <option value="Normal">Normal (7-10 Days)</option>
              <option value="Medium">Medium (5-7 Days)</option>
              <option value="High">High (3-4 Days)</option>
              <option value="Emergency">Emergency (1-2 Days)</option>
            </select>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 flex justify-end gap-3">
          {onClose && <button type="button" onClick={onClose} className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm font-medium transition-colors">Cancel</button>}
          <button type="submit" className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium transition-colors shadow-sm">Submit Request</button>
        </div>
      </form>
    </div>
  );
};
