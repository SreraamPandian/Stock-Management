import React, { useState } from 'react';
import { PurchaseRequest } from '../../types';
import { useProcurement } from '../../context/ProcurementContext';
import { TimelineStepper } from '../shared/TimelineStepper';
import { SLATimer } from '../shared/SLATimer';
import { X, FileText, Check, Ban, Clock } from 'lucide-react';
import { BarcodeScanner } from '../forms/BarcodeScanner';

interface Props {
  pr: PurchaseRequest;
  onClose: () => void;
}

export const PRDetailModal = ({ pr, onClose }: Props) => {
  const { role, updatePRStatus, extendTAT } = useProcurement();
  const [remarks, setRemarks] = useState('');
  const [showRejectReason, setShowRejectReason] = useState(false);
  const [showExtendTAT, setShowExtendTAT] = useState(false);
  const [selectedVendor, setSelectedVendor] = useState<number | null>(null);

  const handleAction = (status: any, extraData = {}) => {
    if ((status === 'Rejected - Action Required' || (status === 'Pending - Procurement' && role === 'Central Store')) && !remarks) {
      alert('Remarks/Reason is mandatory for this action.');
      return;
    }
    updatePRStatus(pr.id, status, remarks, extraData);
    onClose();
  };

  const handleExtendTAT = () => {
    if (!remarks) {
      alert('Reason for TAT extension is mandatory.');
      return;
    }
    extendTAT(pr.id, 24, remarks); // Extend by 24 hours
    setShowExtendTAT(false);
    setRemarks('');
  };

  const isFinanceGuardActive = role === 'Finance' && pr.smdApproved && (pr.priority === 'Emergency' || pr.priority === 'High');

  const renderActionButtons = () => {
    switch (role) {
      case 'Sub Store Keeper':
        if (pr.status === 'PO Issued' || pr.status === 'Dispatched - In Transit') {
          return (
            <div className="w-full space-y-4">
              <div className="bg-blue-50 p-3 rounded text-sm text-blue-800 border border-blue-200">
                <strong>Goods Receipt Note (GRN):</strong> Scan the items to confirm receipt and update local stock.
              </div>
              <BarcodeScanner onScan={(code) => handleAction('Closed - Completed', { notes: `Goods Received. Barcode: ${code}` })} />
            </div>
          );
        }
        return null;

      case 'Centre In-Charge':
        return (
          <>
            <button onClick={() => setShowRejectReason(true)} className="px-4 py-2 border border-rose-200 text-rose-600 rounded-lg hover:bg-rose-50 font-medium transition-colors">Reject</button>
            <button onClick={() => handleAction('Pending - Central Store')} className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-900 font-medium transition-colors">Forward to Central Store</button>
            <button onClick={() => handleAction('Pending - Procurement')} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition-colors">Direct to Procurement</button>
          </>
        );

      case 'Central Store':
        return (
          <div className="w-full space-y-4">
            <textarea 
              placeholder="Add Comments/Remarks (Mandatory if forwarding to Procurement)" 
              className="w-full border border-slate-300 rounded-lg p-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              value={remarks}
              onChange={e => setRemarks(e.target.value)}
              rows={2}
            />
            <div className="flex justify-end gap-3">
              <button 
                onClick={() => handleAction('Pending - Procurement', { notes: remarks })} 
                disabled={!remarks}
                className="px-4 py-2 border border-amber-200 text-amber-700 rounded-lg hover:bg-amber-50 font-medium disabled:opacity-50 transition-colors"
              >
                No Stock - Forward to Procurement
              </button>
              <button onClick={() => handleAction('Dispatched - In Transit', { notes: 'Dispatched from Central Store to Sub Store' })} className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 font-medium transition-colors">
                Dispatch Stock
              </button>
            </div>
          </div>
        );

      case 'Procurement Officer':
        if (showExtendTAT) {
          return (
            <div className="w-full flex items-center gap-3">
              <input type="text" placeholder="Reason for TAT extension..." className="flex-1 border border-amber-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-amber-500 outline-none" value={remarks} onChange={e => setRemarks(e.target.value)} autoFocus />
              <button onClick={() => setShowExtendTAT(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-200 rounded-lg text-sm font-medium transition-colors">Cancel</button>
              <button onClick={handleExtendTAT} className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 text-sm font-medium transition-colors">Confirm Extension (+24h)</button>
            </div>
          );
        }
        return (
          <div className="w-full space-y-4">
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
              <h4 className="text-sm font-semibold mb-3">Sourcing Comparison</h4>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { id: 1, name: 'MedSupply Co.', price: 4500, days: 2 },
                  { id: 2, name: 'Global Health', price: 4200, days: 5 },
                  { id: 3, name: 'FastCare Inc.', price: 5100, days: 1 }
                ].map(v => (
                  <div key={v.id} onClick={() => setSelectedVendor(v.id)} className={`p-3 border rounded-md cursor-pointer transition-all ${selectedVendor === v.id ? 'border-blue-500 bg-blue-50 shadow-sm' : 'border-slate-200 bg-white hover:border-blue-300'}`}>
                    <p className="font-semibold text-sm">{v.name}</p>
                    <p className="text-xs text-slate-500 mt-1">Price: AED {v.price}</p>
                    <p className="text-xs text-slate-500">Delivery: {v.days} Days</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex justify-between items-center">
              <button onClick={() => setShowExtendTAT(true)} className="flex items-center gap-1 text-amber-600 hover:text-amber-700 text-sm font-medium">
                <Clock className="w-4 h-4" /> Extend TAT
              </button>
              <button disabled={!selectedVendor} onClick={() => handleAction('Pending - SMD', { vendor: 'Selected Vendor', price: 4500 })} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium disabled:opacity-50 transition-colors">
                Create PO & Forward to SMD
              </button>
            </div>
          </div>
        );

      case 'SMD':
        return (
          <>
            <button onClick={() => setShowRejectReason(true)} className="px-4 py-2 border border-rose-200 text-rose-600 rounded-lg hover:bg-rose-50 font-medium transition-colors">Reject</button>
            <button onClick={() => handleAction('Pending - Finance')} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition-colors">Executive Approval</button>
          </>
        );

      case 'Finance':
        return (
          <div className="w-full space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Payment Mode</label>
                <select className="w-full border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                  <option>Bank Transfer</option>
                  <option>Cheque</option>
                  <option>Cash</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Structure</label>
                <select className="w-full border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                  <option>100% Advance</option>
                  <option>50/50 Milestone</option>
                  <option>Post Delivery</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-3">
              <div className="relative group">
                <button 
                  disabled={isFinanceGuardActive} 
                  onClick={() => setShowRejectReason(true)} 
                  className="px-4 py-2 border border-rose-200 text-rose-600 rounded-lg hover:bg-rose-50 font-medium disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Reject
                </button>
                {isFinanceGuardActive && (
                  <div className="absolute bottom-full mb-2 hidden group-hover:block w-48 p-2 bg-slate-800 text-white text-xs rounded shadow-lg z-50">
                    SMD approved High/Emergency Priority cannot be rejected by Finance.
                  </div>
                )}
              </div>
              <button onClick={() => handleAction('PO Issued')} className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 font-medium transition-colors">Authorize Payment & Issue PO</button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-slate-100 sticky top-0 bg-white z-20">
          <div>
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              {pr.id}
            </h2>
            <p className="text-sm text-slate-500 mt-1">Requested by {pr.requester} • {pr.department}</p>
          </div>
          <div className="flex items-center gap-4">
            {pr.status !== 'Closed - Completed' && <SLATimer deadline={pr.slaDeadline} />}
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
              <X className="w-5 h-5 text-slate-500" />
            </button>
          </div>
        </div>

        <div className="p-6 flex-1">
          <TimelineStepper currentStatus={pr.status} />

          <div className="grid grid-cols-2 gap-6 mt-8">
            <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Request Details</h3>
              <dl className="space-y-3 text-sm">
                <div className="flex justify-between"><dt className="text-slate-500">Category</dt><dd className="font-semibold text-slate-800">{pr.category}</dd></div>
                <div className="flex justify-between"><dt className="text-slate-500">Quantity</dt><dd className="font-semibold text-slate-800">{pr.quantity} Units</dd></div>
                <div className="flex justify-between">
                  <dt className="text-slate-500">Priority</dt>
                  <dd>
                    <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                      pr.priority === 'Emergency' ? 'bg-rose-100 text-rose-700' :
                      pr.priority === 'High' ? 'bg-amber-100 text-amber-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>{pr.priority}</span>
                  </dd>
                </div>
              </dl>
            </div>

            <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Audit Trail</h3>
              <div className="space-y-4 max-h-40 overflow-y-auto pr-2">
                {pr.history.map((h, i) => (
                  <div key={h.id} className="flex gap-3 text-sm relative">
                    {i !== pr.history.length - 1 && <div className="absolute left-[9px] top-6 bottom-[-16px] w-[2px] bg-slate-200"></div>}
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 z-10 ${
                      h.action === 'Rejected' ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'
                    }`}>
                      {h.action === 'Rejected' ? <Ban className="w-3 h-3" /> : <Check className="w-3 h-3" />}
                    </div>
                    <div>
                      <p className="font-medium text-slate-800">{h.stage} <span className="text-slate-500 font-normal text-xs ml-1">({h.userRole})</span></p>
                      <p className="text-xs text-slate-500 mt-0.5">{new Date(h.timestamp).toLocaleString()}</p>
                      {h.notes && <p className="text-xs text-slate-600 mt-1 bg-white p-2 border rounded shadow-sm">{h.notes}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {pr.status !== 'Closed - Completed' && (
          <div className="p-6 border-t border-slate-100 bg-slate-50 rounded-b-xl flex justify-end gap-3">
            {showRejectReason ? (
              <div className="w-full flex items-center gap-3">
                <input 
                  type="text" 
                  placeholder="Mandatory rejection reason..." 
                  className="flex-1 border border-rose-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-rose-500 outline-none"
                  value={remarks}
                  onChange={e => setRemarks(e.target.value)}
                  autoFocus
                />
                <button onClick={() => setShowRejectReason(false)} className="px-4 py-2 text-slate-600 hover:bg-slate-200 rounded-lg text-sm font-medium transition-colors">Cancel</button>
                <button onClick={() => handleAction('Rejected - Action Required')} className="px-4 py-2 bg-rose-600 text-white rounded-lg hover:bg-rose-700 text-sm font-medium transition-colors">Confirm Reject</button>
              </div>
            ) : (
              renderActionButtons()
            )}
          </div>
        )}
      </div>
    </div>
  );
};
