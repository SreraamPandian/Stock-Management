import React, { useState } from 'react';
import { useProcurement } from '../../context/ProcurementContext';
import { PurchaseRequest } from '../../types';
import { PRDetailModal } from './PRDetailModal';
import { Plus, Filter, Clock, CheckCircle, MapPin } from 'lucide-react';
import { SLATimer } from '../shared/SLATimer';

export const Dashboard = () => {
  const { role, branch, prs, setActiveTab } = useProcurement();
  const [selectedPR, setSelectedPR] = useState<PurchaseRequest | null>(null);

  const getRelevantPRs = () => {
    // Local roles only see their branch. Common roles see all branches.
    let filteredPrs = prs;
    if (role === 'Sub Store Keeper' || role === 'Centre In-Charge') {
      filteredPrs = prs.filter(pr => pr.branch === branch);
    }

    switch (role) {
      case 'Sub Store Keeper': return filteredPrs; 
      case 'Centre In-Charge': return filteredPrs.filter(pr => pr.status === 'Pending - Centre In-Charge');
      case 'Central Store': return filteredPrs.filter(pr => pr.status === 'Pending - Central Store');
      case 'Procurement Officer': return filteredPrs.filter(pr => pr.status === 'Pending - Procurement');
      case 'SMD': return filteredPrs.filter(pr => pr.status === 'Pending - SMD');
      case 'Finance': return filteredPrs.filter(pr => pr.status === 'Pending - Finance');
      default: return [];
    }
  };

  const relevantPRs = getRelevantPRs();
  const breachedPRs = relevantPRs.filter(pr => pr.slaDeadline < Date.now() && pr.status !== 'Closed - Completed').length;
  const completedPRs = relevantPRs.filter(pr => pr.status === 'Closed - Completed').length;

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Task Queue</h1>
          <p className="text-slate-500 mt-1">
            Managing requests for <span className="font-semibold text-blue-600">{role}</span>
            {(role === 'Sub Store Keeper' || role === 'Centre In-Charge') && (
              <span> at <span className="font-semibold text-blue-600">{branch}</span></span>
            )}
          </p>
        </div>
        {role === 'Sub Store Keeper' && (
          <button 
            onClick={() => setActiveTab('PR Entry')}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors shadow-sm font-medium"
          >
            <Plus className="w-5 h-5" /> Raise New PR
          </button>
        )}
      </div>

      <div className="grid grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm border-t-4 border-t-blue-500 p-5 border border-slate-100">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-500">Pending Tasks</p>
              <p className="text-3xl font-bold text-slate-800 mt-2">{relevantPRs.filter(pr => pr.status !== 'Closed - Completed').length}</p>
            </div>
            <div className="p-2 bg-blue-50 rounded-lg text-blue-600"><Clock className="w-6 h-6" /></div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border-t-4 border-t-rose-500 p-5 border border-slate-100">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-500">SLA Breached</p>
              <p className="text-3xl font-bold text-rose-600 mt-2">{breachedPRs}</p>
            </div>
            <div className="p-2 bg-rose-50 rounded-lg text-rose-600"><Clock className="w-6 h-6" /></div>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border-t-4 border-t-emerald-500 p-5 border border-slate-100">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-500">Completed PRs</p>
              <p className="text-3xl font-bold text-emerald-600 mt-2">{completedPRs}</p>
            </div>
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600"><CheckCircle className="w-6 h-6" /></div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-slate-50">
          <h2 className="font-semibold text-slate-800">Action Required</h2>
          <button className="text-slate-500 hover:text-blue-600 flex items-center gap-1 text-sm font-medium">
            <Filter className="w-4 h-4" /> Filter
          </button>
        </div>
        
        {relevantPRs.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <CheckCircle className="w-12 h-12 mx-auto text-emerald-400 mb-3" />
            <p className="text-lg font-medium text-slate-700">All caught up!</p>
            <p className="text-sm">No pending tasks for your role at the moment.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-white border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500">
                  <th className="p-4 font-semibold">PR ID</th>
                  <th className="p-4 font-semibold">Branch & Dept</th>
                  <th className="p-4 font-semibold">Priority</th>
                  <th className="p-4 font-semibold">Status</th>
                  <th className="p-4 font-semibold text-right">SLA Timer</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {relevantPRs.map(pr => (
                  <tr 
                    key={pr.id} 
                    onClick={() => setSelectedPR(pr)}
                    className="hover:bg-slate-50 cursor-pointer transition-colors group"
                  >
                    <td className="p-4">
                      <span className="font-semibold text-blue-600 group-hover:underline">{pr.id}</span>
                      <p className="text-xs text-slate-500 mt-0.5">{pr.category}</p>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-1 text-sm text-slate-700 font-medium">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" /> {pr.branch}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{pr.department}</p>
                    </td>
                    <td className="p-4">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold ${
                        pr.priority === 'Emergency' ? 'bg-rose-100 text-rose-700' :
                        pr.priority === 'High' ? 'bg-amber-100 text-amber-700' :
                        'bg-blue-100 text-blue-700'
                      }`}>
                        {pr.priority}
                      </span>
                    </td>
                    <td className="p-4">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                        pr.status.includes('Pending') ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                        pr.status.includes('Rejected') ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                        'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      }`}>
                        {pr.status}
                      </span>
                    </td>
                    <td className="p-4 text-right flex justify-end">
                      {pr.status !== 'Closed - Completed' ? <SLATimer deadline={pr.slaDeadline} /> : <span className="text-xs text-slate-400 font-medium">Closed</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {selectedPR && <PRDetailModal pr={selectedPR} onClose={() => setSelectedPR(null)} />}
    </div>
  );
};
