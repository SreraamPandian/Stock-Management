import React from 'react';
import { Package, Search, Filter } from 'lucide-react';

const mockInventory = [
  { id: 'ITM-001', name: 'Surgical Masks (Box of 50)', category: 'Consumables', burDubai: 1200, alQuoz: 850, central: 5000, status: 'In Stock' },
  { id: 'ITM-002', name: 'MRI Contrast Agent 10ml', category: 'Medications', burDubai: 15, alQuoz: 5, central: 100, status: 'Low Stock' },
  { id: 'ITM-003', name: 'Nitrile Gloves (Large)', category: 'Consumables', burDubai: 400, alQuoz: 300, central: 2000, status: 'In Stock' },
  { id: 'ITM-004', name: 'Defibrillator Pads', category: 'Equipment', burDubai: 2, alQuoz: 0, central: 10, status: 'Critical' },
  { id: 'ITM-005', name: 'Syringes 5ml', category: 'Consumables', burDubai: 3500, alQuoz: 2100, central: 10000, status: 'In Stock' },
];

export const StockView = () => {
  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Global Inventory</h1>
          <p className="text-slate-500 mt-1">Real-time stock visibility across all centers</p>
        </div>
        <div className="flex gap-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
            <input type="text" placeholder="Search items..." className="pl-9 pr-4 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
          </div>
          <button className="flex items-center gap-2 bg-white border border-slate-300 text-slate-700 px-4 py-2 rounded-lg hover:bg-slate-50 transition-colors font-medium text-sm">
            <Filter className="w-4 h-4" /> Filter
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500">
                <th className="p-4 font-semibold">Item Details</th>
                <th className="p-4 font-semibold">Category</th>
                <th className="p-4 font-semibold text-center bg-blue-50/50">Bur Dubai (Sub Store)</th>
                <th className="p-4 font-semibold text-center bg-blue-50/50">Al Quoz (Sub Store)</th>
                <th className="p-4 font-semibold text-center bg-emerald-50/50">Central Store</th>
                <th className="p-4 font-semibold text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mockInventory.map(item => (
                <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-slate-100 rounded-lg text-slate-500"><Package className="w-5 h-5" /></div>
                      <div>
                        <p className="font-semibold text-slate-800">{item.name}</p>
                        <p className="text-xs text-slate-500 font-mono mt-0.5">{item.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 text-sm text-slate-600">{item.category}</td>
                  <td className="p-4 text-center font-medium text-slate-800 bg-blue-50/10">{item.burDubai}</td>
                  <td className="p-4 text-center font-medium text-slate-800 bg-blue-50/10">{item.alQuoz}</td>
                  <td className="p-4 text-center font-bold text-emerald-700 bg-emerald-50/10">{item.central}</td>
                  <td className="p-4 text-right">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                      item.status === 'In Stock' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                      item.status === 'Low Stock' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                      'bg-rose-50 text-rose-700 border border-rose-200'
                    }`}>
                      {item.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
