import React from 'react';
import { Users, Shield, Settings, Key } from 'lucide-react';

const mockUsers = [
  { name: 'Ahmed Khan', role: 'Sub Store Keeper', branch: 'Bur Dubai', status: 'Active' },
  { name: 'Fatima Ali', role: 'Centre In-Charge', branch: 'Bur Dubai', status: 'Active' },
  { name: 'Sarah Smith', role: 'Sub Store Keeper', branch: 'Al Quoz', status: 'Active' },
  { name: 'Dr. Hassan', role: 'Centre In-Charge', branch: 'Al Quoz', status: 'Active' },
  { name: 'Omar Farooq', role: 'Central Store', branch: 'Global', status: 'Active' },
  { name: 'Aisha Rahman', role: 'Procurement Officer', branch: 'Global', status: 'Active' },
  { name: 'John Doe', role: 'SMD', branch: 'Global', status: 'Active' },
  { name: 'Jane Roe', role: 'Finance', branch: 'Global', status: 'On Leave' },
];

export const AdminView = () => {
  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">System Administration</h1>
          <p className="text-slate-500 mt-1">Manage users, roles, and global system settings</p>
        </div>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors font-medium text-sm">
          + Add New User
        </button>
      </div>

      <div className="grid grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex items-center gap-4 cursor-pointer hover:border-blue-300 transition-colors">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-lg"><Shield className="w-6 h-6" /></div>
          <div>
            <h3 className="font-semibold text-slate-800">Role Permissions</h3>
            <p className="text-xs text-slate-500 mt-0.5">Manage access levels</p>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex items-center gap-4 cursor-pointer hover:border-blue-300 transition-colors">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-lg"><Settings className="w-6 h-6" /></div>
          <div>
            <h3 className="font-semibold text-slate-800">SLA Configurations</h3>
            <p className="text-xs text-slate-500 mt-0.5">Adjust timer thresholds</p>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex items-center gap-4 cursor-pointer hover:border-blue-300 transition-colors">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-lg"><Key className="w-6 h-6" /></div>
          <div>
            <h3 className="font-semibold text-slate-800">Security & Audits</h3>
            <p className="text-xs text-slate-500 mt-0.5">View system logs</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center gap-2">
          <Users className="w-5 h-5 text-slate-500" />
          <h2 className="font-semibold text-slate-800">User Directory</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500">
                <th className="p-4 font-semibold">Name</th>
                <th className="p-4 font-semibold">Role</th>
                <th className="p-4 font-semibold">Branch Access</th>
                <th className="p-4 font-semibold">Status</th>
                <th className="p-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mockUsers.map((user, idx) => (
                <tr key={idx} className="hover:bg-slate-50 transition-colors">
                  <td className="p-4 font-medium text-slate-800">{user.name}</td>
                  <td className="p-4 text-sm text-slate-600">{user.role}</td>
                  <td className="p-4 text-sm text-slate-600">{user.branch}</td>
                  <td className="p-4">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                      user.status === 'Active' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="p-4 text-right">
                    <button className="text-blue-600 hover:underline text-sm font-medium">Edit</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
