import React from 'react';
import { Package, BarChart2, Settings } from 'lucide-react';

export const StockView = () => (
  <div className="p-8 max-w-7xl mx-auto">
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
      <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
      <h2 className="text-2xl font-bold text-slate-800 mb-2">Stock Management</h2>
      <p className="text-slate-500">Global inventory view and adjustment panel will be implemented here.</p>
    </div>
  </div>
);

export const AnalyticsView = () => (
  <div className="p-8 max-w-7xl mx-auto">
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
      <BarChart2 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
      <h2 className="text-2xl font-bold text-slate-800 mb-2">Analytics & Reports</h2>
      <p className="text-slate-500">Department-wise consumable usage and rejection history reports.</p>
    </div>
  </div>
);

export const AdminView = () => (
  <div className="p-8 max-w-7xl mx-auto">
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
      <Settings className="w-16 h-16 text-slate-300 mx-auto mb-4" />
      <h2 className="text-2xl font-bold text-slate-800 mb-2">System Administration</h2>
      <p className="text-slate-500">User roles, branch configurations, and SLA policy settings.</p>
    </div>
  </div>
);
