import React from 'react';
import { BarChart2, TrendingUp, AlertTriangle, CheckCircle, PieChart } from 'lucide-react';

export const AnalyticsView = () => {
  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      <div className="flex justify-between items-end mb-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Analytics & Reports</h1>
          <p className="text-slate-500 mt-1">System-wide procurement insights for the current month</p>
        </div>
        <button className="flex items-center gap-2 bg-white border border-slate-300 text-slate-700 px-4 py-2 rounded-lg hover:bg-slate-50 transition-colors font-medium text-sm">
          Export Report (Excel)
        </button>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-500">Total Spend</p>
              <p className="text-2xl font-bold text-slate-800 mt-1">AED 142,500</p>
            </div>
            <div className="p-2 bg-blue-50 rounded-lg text-blue-600"><TrendingUp className="w-5 h-5" /></div>
          </div>
          <p className="text-xs text-emerald-600 mt-3 font-medium">↑ 12% vs last month</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-500">PRs Processed</p>
              <p className="text-2xl font-bold text-slate-800 mt-1">348</p>
            </div>
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600"><CheckCircle className="w-5 h-5" /></div>
          </div>
          <p className="text-xs text-emerald-600 mt-3 font-medium">↑ 5% vs last month</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-500">SLA Breaches</p>
              <p className="text-2xl font-bold text-slate-800 mt-1">12</p>
            </div>
            <div className="p-2 bg-rose-50 rounded-lg text-rose-600"><AlertTriangle className="w-5 h-5" /></div>
          </div>
          <p className="text-xs text-rose-600 mt-3 font-medium">↓ 2% vs last month</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-500">Avg TAT (Days)</p>
              <p className="text-2xl font-bold text-slate-800 mt-1">3.2</p>
            </div>
            <div className="p-2 bg-amber-50 rounded-lg text-amber-600"><BarChart2 className="w-5 h-5" /></div>
          </div>
          <p className="text-xs text-slate-500 mt-3 font-medium">Consistent</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <PieChart className="w-5 h-5 text-blue-500" /> Department-wise Usage
          </h3>
          <div className="space-y-4">
            {[
              { dept: 'Emergency', pct: 45, color: 'bg-rose-500' },
              { dept: 'Cardiology', pct: 25, color: 'bg-blue-500' },
              { dept: 'Pharmacy', pct: 20, color: 'bg-emerald-500' },
              { dept: 'Laboratory', pct: 10, color: 'bg-amber-500' },
            ].map(d => (
              <div key={d.dept}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium text-slate-700">{d.dept}</span>
                  <span className="text-slate-500">{d.pct}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2">
                  <div className={`${d.color} h-2 rounded-full`} style={{ width: `${d.pct}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-semibold text-slate-800 mb-4">Recent Rejections</h3>
          <div className="space-y-3">
            {[
              { id: 'PR-2025-089', by: 'Centre In-Charge', reason: 'Exceeds monthly quota', date: 'Today' },
              { id: 'PR-2025-072', by: 'SMD', reason: 'Alternative vendor available', date: 'Yesterday' },
              { id: 'PR-2025-065', by: 'Finance', reason: 'Budget exhausted for Q1', date: '2 days ago' },
            ].map(r => (
              <div key={r.id} className="p-3 border border-slate-100 bg-slate-50 rounded-lg">
                <div className="flex justify-between items-start">
                  <span className="font-semibold text-sm text-blue-600">{r.id}</span>
                  <span className="text-xs text-slate-400">{r.date}</span>
                </div>
                <p className="text-sm text-slate-700 mt-1">Rejected by: <span className="font-medium">{r.by}</span></p>
                <p className="text-xs text-rose-600 mt-1 bg-rose-50 p-1.5 rounded inline-block">Reason: {r.reason}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
