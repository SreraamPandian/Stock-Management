import React from 'react';
import { PRStatus } from '../../types';
import { Check } from 'lucide-react';

const stages = [
  { id: 'init', label: 'Initiated', match: [] },
  { id: 'centre', label: 'Centre Approval', match: ['Pending - Centre In-Charge'] },
  { id: 'store', label: 'Central Store Check', match: ['Pending - Central Store'] },
  { id: 'proc', label: 'Procurement', match: ['Pending - Procurement'] },
  { id: 'smd', label: 'SMD Approval', match: ['Pending - SMD'] },
  { id: 'finance', label: 'Finance Clearance', match: ['Pending - Finance'] },
  { id: 'po', label: 'PO Issued', match: ['PO Issued'] },
  { id: 'closed', label: 'Closed', match: ['Closed - Completed'] },
];

export const TimelineStepper = ({ currentStatus }: { currentStatus: PRStatus }) => {
  let currentIndex = stages.findIndex(s => s.match.includes(currentStatus));
  if (currentIndex === -1) {
    if (currentStatus === 'Rejected') currentIndex = -1; // Handle rejected state visually if needed
    else currentIndex = 0; // Default to init
  }

  return (
    <div className="w-full py-6">
      <div className="flex items-center justify-between relative">
        <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-full h-1 bg-slate-200 rounded-full z-0"></div>
        <div 
          className="absolute left-0 top-1/2 transform -translate-y-1/2 h-1 bg-blue-500 rounded-full z-0 transition-all duration-500"
          style={{ width: `${currentIndex === -1 ? 100 : (currentIndex / (stages.length - 1)) * 100}%`, backgroundColor: currentStatus === 'Rejected' ? '#f43f5e' : '' }}
        ></div>

        {stages.map((stage, index) => {
          const isCompleted = index < currentIndex || currentStatus === 'Closed - Completed';
          const isActive = index === currentIndex;
          const isRejected = currentStatus === 'Rejected';

          return (
            <div key={stage.id} className="relative z-10 flex flex-col items-center group">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-colors duration-300 ${
                isCompleted 
                  ? 'bg-emerald-500 border-emerald-500 text-white' 
                  : isActive
                    ? 'bg-white border-blue-600 text-blue-600 shadow-[0_0_0_4px_rgba(37,99,235,0.1)]'
                    : isRejected && index > currentIndex
                      ? 'bg-white border-slate-200 text-slate-300'
                      : 'bg-white border-slate-300 text-slate-400'
              }`}>
                {isCompleted ? <Check className="w-4 h-4" /> : <span className="text-xs font-bold">{index + 1}</span>}
              </div>
              <span className={`absolute top-10 text-[10px] font-semibold whitespace-nowrap ${
                isActive ? 'text-blue-700' : isCompleted ? 'text-slate-700' : 'text-slate-400'
              }`}>
                {stage.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
