import React from 'react';
import { ProcurementProvider, useProcurement } from './context/ProcurementContext';
import { Layout } from './components/layout/Layout';
import { Dashboard } from './components/dashboard/Dashboard';
import { NewPRForm } from './components/forms/NewPRForm';
import { StockView } from './components/views/StockView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { AdminView } from './components/views/AdminView';

const AppContent = () => {
  const { activeTab, setActiveTab } = useProcurement();

  const renderContent = () => {
    switch (activeTab) {
      case 'Dashboard':
        return <Dashboard />;
      case 'PR Entry':
        return (
          <div className="p-8">
            <h1 className="text-2xl font-bold text-slate-900 mb-6">Create Purchase Request</h1>
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 max-w-2xl">
               <button 
                  onClick={() => setActiveTab('Dashboard')}
                  className="mb-4 text-sm text-blue-600 hover:underline"
                >
                  &larr; Back to Dashboard
                </button>
               <NewPRForm onClose={() => setActiveTab('Dashboard')} />
            </div>
          </div>
        );
      case 'Stock':
        return <StockView />;
      case 'Analytics':
        return <AnalyticsView />;
      case 'Admin':
        return <AdminView />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout>
      {renderContent()}
    </Layout>
  );
};

function App() {
  return (
    <ProcurementProvider>
      <AppContent />
    </ProcurementProvider>
  );
}

export default App;
