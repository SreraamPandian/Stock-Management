import React, { createContext, useContext, useState, ReactNode } from 'react';
import { PurchaseRequest, Role, PRStatus, Tab } from '../types';

interface ProcurementContextType {
  role: Role;
  setRole: (role: Role) => void;
  branch: string;
  setBranch: (branch: string) => void;
  activeTab: Tab;
  setActiveTab: (tab: Tab) => void;
  prs: PurchaseRequest[];
  addPR: (pr: Omit<PurchaseRequest, 'id' | 'createdAt' | 'history' | 'smdApproved'>) => void;
  updatePRStatus: (id: string, newStatus: PRStatus, notes?: string, extraData?: Partial<PurchaseRequest>) => void;
  extendTAT: (id: string, additionalHours: number, reason: string) => void;
}

const now = Date.now();
const hour = 3600000;

const initialState: PurchaseRequest[] = [
  {
    id: 'PR-2025-001', branch: 'Bur Dubai', department: 'Cardiology', category: 'Surgical Instruments', quantity: 50, requester: 'Dr. Ahmed', priority: 'Normal',
    status: 'Pending - Centre In-Charge', createdAt: now - hour, slaDeadline: now + (24 * hour), smdApproved: false,
    history: [{ id: 'h1', stage: 'Initiation', action: 'Raised PR', timestamp: now - hour, userRole: 'Sub Store Keeper' }]
  },
  {
    id: 'PR-2025-002', branch: 'Al Quoz', department: 'Emergency', category: 'Life Support Consumables', quantity: 200, requester: 'Nurse Fatima', priority: 'Emergency',
    status: 'Pending - Centre In-Charge', createdAt: now - (2 * hour), slaDeadline: now - (1 * hour), smdApproved: false,
    history: [{ id: 'h2', stage: 'Initiation', action: 'Raised PR', timestamp: now - (2 * hour), userRole: 'Sub Store Keeper' }]
  },
  {
    id: 'PR-2025-003', branch: 'Bur Dubai', department: 'Pharmacy', category: 'Medications', quantity: 500, requester: 'Pharm. Ali', priority: 'High',
    status: 'Pending - Central Store', createdAt: now - (24 * hour), slaDeadline: now + (12 * hour), smdApproved: false,
    history: [
      { id: 'h3', stage: 'Initiation', action: 'Raised PR', timestamp: now - (24 * hour), userRole: 'Sub Store Keeper' },
      { id: 'h4', stage: 'Centre Approval', action: 'Approved', timestamp: now - (20 * hour), userRole: 'Centre In-Charge' }
    ]
  },
  {
    id: 'PR-2025-004', branch: 'Al Quoz', department: 'Laboratory', category: 'Consumables', quantity: 1000, requester: 'Tech Sarah', priority: 'Medium',
    status: 'Pending - Procurement', createdAt: now - (48 * hour), slaDeadline: now + (24 * hour), smdApproved: false,
    history: [
      { id: 'h5', stage: 'Initiation', action: 'Raised PR', timestamp: now - (48 * hour), userRole: 'Sub Store Keeper' },
      { id: 'h6', stage: 'Centre Approval', action: 'Approved', timestamp: now - (40 * hour), userRole: 'Centre In-Charge' },
      { id: 'h7', stage: 'Central Store', action: 'Forwarded to Procurement', timestamp: now - (24 * hour), userRole: 'Central Store', notes: 'Stock Unavailable globally' }
    ]
  },
  {
    id: 'PR-2025-005', branch: 'Bur Dubai', department: 'ICU', category: 'Equipment', quantity: 2, requester: 'Dr. Hassan', priority: 'Emergency',
    status: 'Pending - SMD', createdAt: now - (72 * hour), slaDeadline: now + (2 * hour), smdApproved: false,
    history: [
      { id: 'h8', stage: 'Initiation', action: 'Raised PR', timestamp: now - (72 * hour), userRole: 'Sub Store Keeper' },
      { id: 'h9', stage: 'Centre Approval', action: 'Approved', timestamp: now - (70 * hour), userRole: 'Centre In-Charge' },
      { id: 'h10', stage: 'Procurement', action: 'Sourced & Forwarded', timestamp: now - (24 * hour), userRole: 'Procurement Officer', notes: 'Vendor: MedSupply Co.' }
    ]
  },
  {
    id: 'PR-2025-006', branch: 'Al Quoz', department: 'Radiology', category: 'MRI Contrast Agent', quantity: 100, requester: 'Dr. Smith', priority: 'High',
    status: 'Pending - Finance', createdAt: now - (96 * hour), slaDeadline: now + (8 * hour), smdApproved: true,
    history: [
      { id: 'h11', stage: 'Initiation', action: 'Raised PR', timestamp: now - (96 * hour), userRole: 'Sub Store Keeper' },
      { id: 'h12', stage: 'SMD Approval', action: 'Approved', timestamp: now - (24 * hour), userRole: 'SMD' }
    ]
  },
  {
    id: 'PR-2025-007', branch: 'Bur Dubai', department: 'General Ward', category: 'Consumables', quantity: 300, requester: 'Nurse Joy', priority: 'Normal',
    status: 'PO Issued', createdAt: now - (120 * hour), slaDeadline: now + (48 * hour), smdApproved: true,
    history: [
      { id: 'h13', stage: 'Initiation', action: 'Raised PR', timestamp: now - (120 * hour), userRole: 'Sub Store Keeper' },
      { id: 'h14', stage: 'Finance', action: 'Approved', timestamp: now - (24 * hour), userRole: 'Finance', notes: 'Payment Authorized' }
    ]
  },
  {
    id: 'PR-2025-008', branch: 'Al Quoz', department: 'Dental', category: 'Surgical Instruments', quantity: 20, requester: 'Dr. Omar', priority: 'Medium',
    status: 'Closed - Completed', createdAt: now - (200 * hour), slaDeadline: now - (50 * hour), smdApproved: true,
    history: [
      { id: 'h15', stage: 'Initiation', action: 'Raised PR', timestamp: now - (200 * hour), userRole: 'Sub Store Keeper' },
      { id: 'h16', stage: 'PO Issued', action: 'Approved', timestamp: now - (100 * hour), userRole: 'Finance' },
      { id: 'h17', stage: 'Closed', action: 'Approved/Forwarded', timestamp: now - (48 * hour), userRole: 'Sub Store Keeper', notes: 'Goods Received. Barcode: 8472910293' }
    ]
  }
];

const ProcurementContext = createContext<ProcurementContextType | undefined>(undefined);

export const ProcurementProvider = ({ children }: { children: ReactNode }) => {
  const [role, setRole] = useState<Role>('Sub Store Keeper');
  const [branch, setBranch] = useState<string>('Bur Dubai');
  const [activeTab, setActiveTab] = useState<Tab>('Dashboard');
  const [prs, setPrs] = useState<PurchaseRequest[]>(initialState);

  const addPR = (prData: Omit<PurchaseRequest, 'id' | 'createdAt' | 'history' | 'smdApproved'>) => {
    const newPR: PurchaseRequest = {
      ...prData,
      id: `PR-2025-00${prs.length + 1}`,
      createdAt: Date.now(),
      smdApproved: false,
      history: [{
        id: Math.random().toString(36).substr(2, 9),
        stage: 'Initiation',
        action: 'Raised PR',
        timestamp: Date.now(),
        userRole: role,
      }]
    };
    setPrs([newPR, ...prs]);
    setActiveTab('Dashboard');
  };

  const updatePRStatus = (id: string, newStatus: PRStatus, notes?: string, extraData?: Partial<PurchaseRequest>) => {
    setPrs(currentPrs => currentPrs.map(pr => {
      if (pr.id === id) {
        const newHistoryItem: PRHistory = {
          id: Math.random().toString(36).substr(2, 9),
          stage: newStatus.split(' - ')[0] || newStatus,
          action: newStatus.includes('Rejected') ? 'Rejected' : 'Approved/Forwarded',
          timestamp: Date.now(),
          userRole: role,
          notes
        };
        return { 
          ...pr, 
          status: newStatus, 
          history: [...pr.history, newHistoryItem],
          smdApproved: role === 'SMD' && newStatus === 'Pending - Finance' ? true : pr.smdApproved,
          ...extraData
        };
      }
      return pr;
    }));
  };

  const extendTAT = (id: string, additionalHours: number, reason: string) => {
    setPrs(currentPrs => currentPrs.map(pr => {
      if (pr.id === id) {
        const newHistoryItem: PRHistory = {
          id: Math.random().toString(36).substr(2, 9),
          stage: 'TAT Extension',
          action: 'Extended SLA',
          timestamp: Date.now(),
          userRole: role,
          notes: `Extended by ${additionalHours}h. Reason: ${reason}`
        };
        return {
          ...pr,
          slaDeadline: pr.slaDeadline + (additionalHours * 3600000),
          history: [...pr.history, newHistoryItem]
        };
      }
      return pr;
    }));
  };

  return (
    <ProcurementContext.Provider value={{ role, setRole, branch, setBranch, activeTab, setActiveTab, prs, addPR, updatePRStatus, extendTAT }}>
      {children}
    </ProcurementContext.Provider>
  );
};

export const useProcurement = () => {
  const context = useContext(ProcurementContext);
  if (!context) throw new Error('useProcurement must be used within a ProcurementProvider');
  return context;
};
